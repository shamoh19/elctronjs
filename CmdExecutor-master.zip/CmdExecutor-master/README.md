#CmdExecutor

## Features
- CmdExecutor Application help us to execute multiple command in single application

- No need open multiple command prompt to execute multiple commands, Single application help us to run multiple command 

- You can view the command logs 

- You can save the command

- Cmdexecutor only for windows

## Execute Electorn

Install [Electron](https://github.com/electron-userland/electron-prebuilt) prebuilt binaries for command-line use using npm. This module helps you easily install the electron command for use on the command line without having to compile anything.


#### [Download Released App](https://github.com/parthasharathi/CmdExecutor/releases)
